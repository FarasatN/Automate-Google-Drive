import os

def get_network_type():
    """Check if the Android device is using Wi-Fi or Mobile Data"""
    wifi_status = os.popen("getprop wifi.supplicant.state").read().strip()
    mobile_data_status = os.popen("getprop gsm.network.type").read().strip()

    if wifi_status == "COMPLETED":
        return "Wi-Fi"
    elif mobile_data_status:
        return "Mobile Data"
    else:
        return "Unknown"

network_type = get_network_type()
print(f"Connected via: {network_type}")